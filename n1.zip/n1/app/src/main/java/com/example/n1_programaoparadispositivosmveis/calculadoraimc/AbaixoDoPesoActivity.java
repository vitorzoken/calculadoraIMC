package com.example.n1_programaoparadispositivosmveis.calculadoraimc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.n1_programaoparadispositivosmveis.R;

import java.util.Locale;

public class AbaixoDoPesoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        // Receber dados da Intent
        Bundle bundle = getIntent().getExtras();
        double peso = bundle.getDouble("peso");
        double altura = bundle.getDouble("altura");
        double imc = bundle.getDouble("imc");
        String classificacao = bundle.getString("classificacao");

        // Configurar elementos da UI
        ImageView imgFeedback = findViewById(R.id.img_feedback);
        TextView txtClassificacao = findViewById(R.id.txt_classificacao);
        TextView txtDados = findViewById(R.id.txt_dados);
        TextView txtMensagem = findViewById(R.id.txt_mensagem);
        Button btnFechar = findViewById(R.id.btn_fechar);

        // Definir imagem e textos
        imgFeedback.setImageResource(R.drawable.abaixo_peso);
        txtClassificacao.setText(classificacao);
        txtDados.setText(String.format(Locale.getDefault(),
                "Peso: %.1f kg\nAltura: %.2f m\nIMC: %.1f", peso, altura, imc));
        txtMensagem.setText("Você está abaixo do peso ideal. Consulte um nutricionista para uma dieta balanceada que ajude você a alcançar seu peso saudável. Lembre-se: pequenos progressos são importantes!");

        btnFechar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
