package com.example.n1_programaoparadispositivosmveis.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.n1_programaoparadispositivosmveis.R;

import java.util.Locale;

public class Obesidade1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            double peso = bundle.getDouble("peso");
            double altura = bundle.getDouble("altura");
            double imc = bundle.getDouble("imc");
            String classificacao = bundle.getString("classificacao");

            ImageView imgFeedback = findViewById(R.id.img_feedback);
            TextView txtClassificacao = findViewById(R.id.txt_classificacao);
            TextView txtDados = findViewById(R.id.txt_dados);
            TextView txtMensagem = findViewById(R.id.txt_mensagem);
            Button btnFechar = findViewById(R.id.btn_fechar);

            imgFeedback.setImageResource(R.drawable.obesidade1);
            txtClassificacao.setText(classificacao);
            txtDados.setText(String.format(Locale.getDefault(),
                    "Peso: %.1f kg\nAltura: %.2f m\nIMC: %.1f",
                    peso, altura, imc));

            txtMensagem.setText("Seu IMC indica obesidade grau 1. Não desanime! Este é o momento perfeito " +
                    "para buscar orientação profissional e começar uma jornada de cuidados com a saúde.");

            btnFechar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
        } else {
            finish();
        }
    }
}
