package com.example.n1_programaoparadispositivosmveis.calculadoraimc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.n1_programaoparadispositivosmveis.R;

public class CalculoIMCActivity extends AppCompatActivity {

    private EditText editPeso, editAltura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo_imc);

        editPeso = findViewById(R.id.edit_peso);
        editAltura = findViewById(R.id.edit_altura);

        Button btnCalcular = findViewById(R.id.btn_calcular);
        Button btnLimpar = findViewById(R.id.btn_limpar);
        Button btnFechar = findViewById(R.id.btn_fechar);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularIMC();
            }
        });

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editPeso.setText("");
                editAltura.setText("");
                editPeso.requestFocus();
            }
        });

        btnFechar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularIMC() {
        String pesoStr = editPeso.getText().toString();
        String alturaStr = editAltura.getText().toString();

        if (pesoStr.isEmpty() || alturaStr.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double peso = Double.parseDouble(pesoStr);
            double altura = Double.parseDouble(alturaStr);

            if (altura <= 0 || peso <= 0) {
                Toast.makeText(this, "Valores devem ser maiores que zero", Toast.LENGTH_SHORT).show();
                return;
            }

            double imc = peso / (altura * altura);
            String classificacao = classificarIMC(imc);

            // Passar dados para a activity de feedback
            Intent intent = getFeedbackIntent(imc, classificacao, peso, altura);
            startActivity(intent);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Digite valores válidos", Toast.LENGTH_SHORT).show();
        }
    }

    private String classificarIMC(double imc) {
        if (imc < 18.5) return "Abaixo do peso";
        else if (imc < 25) return "Peso normal";
        else if (imc < 30) return "Sobrepeso";
        else if (imc < 35) return "Obesidade grau 1";
        else if (imc < 40) return "Obesidade grau 2";
        else return "Obesidade grau 3";
    }

    private Intent getFeedbackIntent(double imc, String classificacao, double peso, double altura) {
        Intent intent;

        if (imc < 18.5) intent = new Intent(this, AbaixoDoPesoActivity.class);
        else if (imc < 25) intent = new Intent(this, PesoNormalActivity.class);
        else if (imc < 30) intent = new Intent(this, SobrepesoActivity.class);
        else if (imc < 35) intent = new Intent(this, Obesidade1Activity.class);
        else if (imc < 40) intent = new Intent(this, Obesidade2Activity.class);
        else intent = new Intent(this, Obesidade3Activity.class);

        Bundle bundle = new Bundle();
        bundle.putDouble("peso", peso);
        bundle.putDouble("altura", altura);
        bundle.putDouble("imc", imc);
        bundle.putString("classificacao", classificacao);

        intent.putExtras(bundle);
        return intent;
    }
}
